import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/config/working_hours.dart';
import '../core/constants/app_constants.dart';
import '../core/constants/audit_actions.dart';
import '../core/errors/app_exception.dart';
import '../core/rules/pass_rules.dart';
import '../core/rules/permissions.dart';
import '../core/utils/manila_time.dart';
import '../models/employee.dart';
import '../models/enums.dart';
import '../models/pass_slip.dart';
import '../models/user_profile.dart';
import '../models/user_role.dart';
import 'audit_service.dart';
import 'notification_service.dart';

class PassSlipService {
  PassSlipService(this._db, this._audit, this._notifications);

  final FirebaseFirestore _db;
  final AuditService _audit;
  final NotificationService _notifications;

  static const _guardVisible = ['Approved', 'Out', 'Completed'];

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(FirestoreCollections.passSlips);

  List<PassSlip> _mapList(QuerySnapshot<Map<String, dynamic>> s) => s.docs
      .map((d) => PassSlip.fromMap(d.id, d.data()))
      .whereType<PassSlip>()
      .toList();

  /// Role-aware query shaped to satisfy the Firestore rules:
  /// Admin → all (latest 500) · Department Head → own department (latest 500)
  /// · Guard → Approved/Out/Completed from the last 30 days onward.
  Stream<List<PassSlip>> watchVisible(UserProfile viewer, {DateTime? now}) {
    Query<Map<String, dynamic>> q;
    switch (viewer.role) {
      case UserRole.admin:
        q = _col.orderBy('createdAt', descending: true).limit(500);
      case UserRole.departmentHead:
        final dept = viewer.departmentId;
        if (dept == null) return Stream.value(const []);
        q = _col
            .where('departmentId', isEqualTo: dept)
            .orderBy('createdAt', descending: true)
            .limit(500);
      case UserRole.guard:
        final cutoff = ManilaTime.dayStart(
          (now ?? DateTime.now()).subtract(const Duration(days: 30)),
        );
        q = _col
            .where('status', whereIn: _guardVisible)
            .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(cutoff))
            .orderBy('date', descending: true);
    }
    return q.snapshots().map(_mapList);
  }

  Stream<PassSlip?> watchOne(String passSlipId) => _col
      .doc(passSlipId)
      .snapshots()
      .map(
        (s) => (s.exists && s.data() != null)
            ? PassSlip.fromMap(s.id, s.data()!)
            : null,
      );

  // ---------------------------------------------------------------- create

  Future<String> create({
    required UserProfile actor,
    required Employee employee,
    required DateTime date,
    required DateTime requestedTimeOut,
    required DateTime expectedReturn,
    required String reason,
    required String destination,
  }) async {
    Permissions.require(Permissions.canCreatePassFor(actor, employee));
    final problem = PassRules.validateRequest(
      date: date,
      requestedTimeOut: requestedTimeOut,
      expectedReturn: expectedReturn,
      now: DateTime.now(),
    );
    if (problem != null) throw AppException(problem, code: 'invalid');
    if (reason.trim().isEmpty) throw const AppException('Reason is required.');
    if (destination.trim().isEmpty) {
      throw const AppException('Destination is required.');
    }

    final ref = _col.doc();
    final dayStart = ManilaTime.dayStart(date);
    final batch = _db.batch();
    batch.set(ref, {
      'passSlipId': ref.id,
      'employeeId': employee.employeeId,
      'employeeNumber': employee.employeeNumber,
      'employeeName': employee.fullName,
      'departmentId': employee.departmentId,
      'departmentName': employee.departmentName,
      'employeeType': employee.employeeType.value,
      'date': Timestamp.fromDate(dayStart),
      'requestedTimeOut': Timestamp.fromDate(requestedTimeOut),
      'expectedReturnTime': Timestamp.fromDate(expectedReturn),
      'actualTimeOut': null,
      'actualTimeIn': null,
      'reason': reason.trim(),
      'destination': destination.trim(),
      'requestedBy': actor.uid,
      'requestedByName': actor.fullName,
      'approvedBy': null,
      'approvedByName': null,
      'approvedAt': null,
      'rejectedBy': null,
      'rejectedByName': null,
      'rejectedAt': null,
      'rejectionReason': null,
      'guardTimeOutBy': null,
      'guardTimeInBy': null,
      'status': PassStatus.pending.value,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    _audit.addToBatch(
      batch,
      actor: actor,
      action: AuditActions.passCreated,
      entityType: EntityTypes.passSlip,
      entityId: ref.id,
      newData: {
        'employeeId': employee.employeeId,
        'employeeName': employee.fullName,
        'employeeType': employee.employeeType.value,
        'status': PassStatus.pending.value,
      },
    );
    await batch.commit();
    return ref.id;
  }

  // ------------------------------------------------------ transaction helper

  Future<void> _transition(
    String passSlipId,
    void Function(
      Transaction tx,
      DocumentReference<Map<String, dynamic>> ref,
      PassSlip pass,
    )
    body, {
    String deniedMessage =
        'The server did not allow this action. '
        'The pass slip may have changed — please refresh and try again.',
  }) async {
    final ref = _col.doc(passSlipId);
    try {
      await _db.runTransaction((tx) async {
        final snap = await tx.get(ref);
        final data = snap.data();
        final pass = (snap.exists && data != null)
            ? PassSlip.fromMap(snap.id, data)
            : null;
        if (pass == null) {
          throw const AppException('Pass slip not found.', code: 'not-found');
        }
        body(tx, ref, pass);
      });
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        throw AppException(deniedMessage, code: e.code);
      }
      rethrow;
    }
  }

  // --------------------------------------------------------- update pending

  Future<void> updatePending(
    UserProfile actor,
    String passSlipId, {
    required DateTime date,
    required DateTime requestedTimeOut,
    required DateTime expectedReturn,
    required String reason,
    required String destination,
  }) {
    return _transition(passSlipId, (tx, ref, pass) {
      Permissions.require(Permissions.canEditPending(actor, pass));
      final problem = PassRules.validateRequest(
        date: date,
        requestedTimeOut: requestedTimeOut,
        expectedReturn: expectedReturn,
        now: DateTime.now(),
      );
      if (problem != null) throw AppException(problem, code: 'invalid');
      if (reason.trim().isEmpty || destination.trim().isEmpty) {
        throw const AppException('Reason and destination are required.');
      }
      tx.update(ref, {
        'date': Timestamp.fromDate(ManilaTime.dayStart(date)),
        'requestedTimeOut': Timestamp.fromDate(requestedTimeOut),
        'expectedReturnTime': Timestamp.fromDate(expectedReturn),
        'reason': reason.trim(),
        'destination': destination.trim(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      _audit.addToTransaction(
        tx,
        actor: actor,
        action: AuditActions.passUpdated,
        entityType: EntityTypes.passSlip,
        entityId: pass.passSlipId,
        previousData: {'reason': pass.reason, 'destination': pass.destination},
        newData: {'reason': reason.trim(), 'destination': destination.trim()},
      );
    });
  }

  // ------------------------------------------------------------- approval

  Future<void> approve(UserProfile actor, String passSlipId) {
    return _transition(passSlipId, (tx, ref, pass) {
      if (pass.status != PassStatus.pending) {
        throw const AppException('This pass slip is no longer pending.');
      }
      Permissions.require(Permissions.canDecide(actor, pass));
      tx.update(ref, {
        'status': PassStatus.approved.value,
        'approvedBy': actor.uid,
        'approvedByName': actor.fullName,
        'approvedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      _audit.addToTransaction(
        tx,
        actor: actor,
        action: AuditActions.passApproved,
        entityType: EntityTypes.passSlip,
        entityId: pass.passSlipId,
        previousData: {'status': pass.status.value},
        newData: {'status': PassStatus.approved.value},
      );
      _notifications.passApprovedForGuards(tx, actor: actor, pass: pass);
    });
  }

  Future<void> reject(UserProfile actor, String passSlipId, String reason) {
    final trimmed = reason.trim();
    if (trimmed.isEmpty) {
      throw const AppException(
        'Please enter a reason for rejecting this pass slip.',
      );
    }
    return _transition(passSlipId, (tx, ref, pass) {
      if (pass.status != PassStatus.pending) {
        throw const AppException('This pass slip is no longer pending.');
      }
      Permissions.require(Permissions.canDecide(actor, pass));
      tx.update(ref, {
        'status': PassStatus.rejected.value,
        'rejectedBy': actor.uid,
        'rejectedByName': actor.fullName,
        'rejectedAt': FieldValue.serverTimestamp(),
        'rejectionReason': trimmed,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      _audit.addToTransaction(
        tx,
        actor: actor,
        action: AuditActions.passRejected,
        entityType: EntityTypes.passSlip,
        entityId: pass.passSlipId,
        previousData: {'status': pass.status.value},
        newData: {
          'status': PassStatus.rejected.value,
          'rejectionReason': trimmed,
        },
      );
      _notifications.passRejectedForRequester(
        tx,
        actor: actor,
        pass: pass,
        reason: trimmed,
      );
    });
  }

  Future<void> cancel(UserProfile actor, String passSlipId, {String? reason}) {
    return _transition(passSlipId, (tx, ref, pass) {
      if (pass.status == PassStatus.out) {
        throw const AppException(
          'The employee has already left, so this pass slip cannot be cancelled.',
        );
      }
      if (pass.status != PassStatus.pending &&
          pass.status != PassStatus.approved) {
        throw const AppException(
          'Only pending or approved pass slips can be cancelled.',
        );
      }
      Permissions.require(Permissions.canCancel(actor, pass));
      tx.update(ref, {
        'status': PassStatus.cancelled.value,
        'cancelledBy': actor.uid,
        'cancelledByName': actor.fullName,
        'cancelledAt': FieldValue.serverTimestamp(),
        'cancellationReason': (reason ?? '').trim(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      _audit.addToTransaction(
        tx,
        actor: actor,
        action: AuditActions.passCancelled,
        entityType: EntityTypes.passSlip,
        entityId: pass.passSlipId,
        previousData: {'status': pass.status.value},
        newData: {'status': PassStatus.cancelled.value},
      );
    });
  }

  // ------------------------------------------------------- guard operations

  Future<void> recordTimeOut(
    UserProfile actor,
    String passSlipId,
    WorkingHours hours,
  ) {
    return _transition(
      passSlipId,
      (tx, ref, pass) {
        Permissions.require(Permissions.canRecordGuardActions(actor));
        final blocker = PassRules.timeOutBlocker(pass, DateTime.now(), hours);
        if (blocker != null) throw AppException(blocker, code: 'blocked');
        tx.update(ref, {
          'status': PassStatus.out.value,
          'actualTimeOut': FieldValue.serverTimestamp(),
          'guardTimeOutBy': actor.uid,
          'guardTimeOutByName': actor.fullName,
          'updatedAt': FieldValue.serverTimestamp(),
        });
        _audit.addToTransaction(
          tx,
          actor: actor,
          action: AuditActions.guardTimeOut,
          entityType: EntityTypes.passSlip,
          entityId: pass.passSlipId,
          previousData: {'status': pass.status.value},
          newData: {'status': PassStatus.out.value},
        );
      },
      deniedMessage:
          'Time Out was rejected by the server. It can only be recorded '
          'for an approved pass dated today, during working hours (${hours.label}).',
    );
  }

  Future<void> recordTimeIn(
    UserProfile actor,
    String passSlipId,
    WorkingHours hours,
  ) {
    return _transition(
      passSlipId,
      (tx, ref, pass) {
        Permissions.require(Permissions.canRecordGuardActions(actor));
        final blocker = PassRules.timeInBlocker(pass, DateTime.now(), hours);
        if (blocker != null) throw AppException(blocker, code: 'blocked');
        tx.update(ref, {
          'status': PassStatus.completed.value,
          'actualTimeIn': FieldValue.serverTimestamp(),
          'guardTimeInBy': actor.uid,
          'guardTimeInByName': actor.fullName,
          'updatedAt': FieldValue.serverTimestamp(),
        });
        _audit.addToTransaction(
          tx,
          actor: actor,
          action: AuditActions.guardTimeIn,
          entityType: EntityTypes.passSlip,
          entityId: pass.passSlipId,
          previousData: {'status': pass.status.value},
          newData: {'status': PassStatus.completed.value},
        );
      },
      deniedMessage:
          'Time In was rejected by the server. It can only be recorded '
          'for an employee who is out, during working hours (${hours.label}).',
    );
  }
}
