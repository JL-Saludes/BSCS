import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import '../core/constants/app_constants.dart';
import '../core/constants/audit_actions.dart';
import '../core/errors/app_exception.dart';
import '../core/rules/permissions.dart';
import '../models/department.dart';
import '../models/user_profile.dart';
import '../models/user_role.dart';
import 'audit_service.dart';

class UserService {
  UserService(this._db, this._auth, this._audit);

  final FirebaseFirestore _db;
  final FirebaseAuth _auth;
  final AuditService _audit;

  static const _creatorAppName = 'userCreator';

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(FirestoreCollections.users);

  Stream<List<UserProfile>> watchAll() => _col
      .orderBy('fullName')
      .snapshots()
      .map(
        (s) => s.docs
            .map((d) => UserProfile.fromMap(d.id, d.data()))
            .whereType<UserProfile>()
            .toList(),
      );

  /// A second FirebaseApp so creating an account never signs the Admin out.
  Future<FirebaseAuth> _creatorAuth() async {
    FirebaseApp app;
    try {
      app = Firebase.app(_creatorAppName);
    } catch (_) {
      app = await Firebase.initializeApp(
        name: _creatorAppName,
        options: Firebase.app().options,
      );
    }
    return FirebaseAuth.instanceFor(app: app);
  }

  String _createMessage(String code) {
    switch (code) {
      case 'email-already-in-use':
        return 'An account with this email already exists.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'weak-password':
        return 'The password is too weak. Use at least 8 characters.';
      case 'network-request-failed':
        return 'No internet connection. Please check your network.';
      default:
        return 'Unable to create the account right now. Please try again.';
    }
  }

  Map<String, dynamic> _summary(
    String fullName,
    UserRole role,
    String? deptId,
    bool active,
  ) => {
    'fullName': fullName,
    'role': role.value,
    'departmentId': deptId,
    'active': active,
  };

  Future<void> create({
    required UserProfile actor,
    required String email,
    required String password,
    required String fullName,
    required UserRole role,
    Department? department,
  }) async {
    Permissions.require(Permissions.canManageUsers(actor));
    if (fullName.trim().isEmpty) {
      throw const AppException('Full name is required.');
    }
    if (password.length < 8) {
      throw const AppException('Password must be at least 8 characters.');
    }
    if (role == UserRole.departmentHead && department == null) {
      throw const AppException('Select a department for the department head.');
    }
    final dept = role == UserRole.departmentHead ? department : null;

    final auth = await _creatorAuth();
    final UserCredential cred;
    try {
      cred = await auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
    } on FirebaseAuthException catch (e) {
      throw AppException(_createMessage(e.code), code: e.code);
    }

    final newUser = cred.user!;
    try {
      final ref = _col.doc(newUser.uid);
      final batch = _db.batch();
      batch.set(ref, {
        'uid': newUser.uid,
        'email': email.trim(),
        'fullName': fullName.trim(),
        'role': role.value,
        'departmentId': dept?.departmentId,
        'departmentName': dept?.departmentName,
        'active': true,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'createdBy': actor.uid,
      });
      _audit.addToBatch(
        batch,
        actor: actor,
        action: AuditActions.userCreated,
        entityType: EntityTypes.user,
        entityId: newUser.uid,
        newData: {
          ..._summary(fullName.trim(), role, dept?.departmentId, true),
          'email': email.trim(),
        },
      );
      await batch.commit();
    } catch (_) {
      // Do not leave an Auth account without a profile.
      try {
        await newUser.delete();
      } catch (_) {}
      rethrow;
    } finally {
      await auth.signOut();
    }
  }

  Future<void> update(
    UserProfile actor,
    UserProfile before, {
    required String fullName,
    required UserRole role,
    Department? department,
  }) async {
    Permissions.require(Permissions.canManageUsers(actor));
    if (actor.uid == before.uid) {
      throw const AppException('You cannot change your own account here.');
    }
    if (fullName.trim().isEmpty) {
      throw const AppException('Full name is required.');
    }
    if (role == UserRole.departmentHead && department == null) {
      throw const AppException('Select a department for the department head.');
    }
    final dept = role == UserRole.departmentHead ? department : null;

    final batch = _db.batch();
    batch.update(_col.doc(before.uid), {
      'fullName': fullName.trim(),
      'role': role.value,
      'departmentId': dept?.departmentId,
      'departmentName': dept?.departmentName,
      'updatedAt': FieldValue.serverTimestamp(),
      'updatedBy': actor.uid,
    });
    _audit.addToBatch(
      batch,
      actor: actor,
      action: AuditActions.userUpdated,
      entityType: EntityTypes.user,
      entityId: before.uid,
      previousData: _summary(
        before.fullName,
        before.role,
        before.departmentId,
        before.active,
      ),
      newData: _summary(
        fullName.trim(),
        role,
        dept?.departmentId,
        before.active,
      ),
    );
    await batch.commit();
  }

  /// Disables or re-enables a user. A disabled user is locked out of all data
  /// by the Firestore rules (every rule checks `active`).
  Future<void> setActive(
    UserProfile actor,
    UserProfile target,
    bool active,
  ) async {
    Permissions.require(Permissions.canManageUsers(actor));
    if (actor.uid == target.uid) {
      throw const AppException('You cannot disable your own account.');
    }
    final batch = _db.batch();
    batch.update(_col.doc(target.uid), {
      'active': active,
      'updatedAt': FieldValue.serverTimestamp(),
      'updatedBy': actor.uid,
    });
    _audit.addToBatch(
      batch,
      actor: actor,
      action: active ? AuditActions.userEnabled : AuditActions.userDisabled,
      entityType: EntityTypes.user,
      entityId: target.uid,
      previousData: {'active': target.active},
      newData: {'active': active},
    );
    await batch.commit();
  }

  Future<void> sendPasswordReset(UserProfile actor, UserProfile target) async {
    Permissions.require(Permissions.canManageUsers(actor));
    await _auth.sendPasswordResetEmail(email: target.email);
    final batch = _db.batch();
    _audit.addToBatch(
      batch,
      actor: actor,
      action: AuditActions.userPasswordReset,
      entityType: EntityTypes.user,
      entityId: target.uid,
    );
    await batch.commit();
  }
}
