import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../core/constants/app_constants.dart';
import '../core/errors/app_exception.dart';
import '../core/errors/error_mapper.dart';
import '../models/user_profile.dart';

class AuthService {
  AuthService(this._auth, this._db);

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;

  Stream<User?> authStateChanges() => _auth.authStateChanges();

  /// Live profile from Firestore. The role is always read from the server
  /// document, never trusted from the client.
  Stream<UserProfile?> watchProfile(String uid) {
    return _db.collection(FirestoreCollections.users).doc(uid).snapshots().map((
      snap,
    ) {
      final data = snap.data();
      if (!snap.exists || data == null) return null;
      return UserProfile.fromMap(uid, data);
    });
  }

  Future<void> signIn({required String email, required String password}) async {
    try {
      await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
    } on FirebaseAuthException catch (e) {
      throw AppException(authErrorMessage(e.code), code: e.code);
    }
  }

  Future<void> signOut() => _auth.signOut();
}
