import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/constants/app_constants.dart';
import '../core/constants/audit_actions.dart';
import '../core/errors/app_exception.dart';
import '../core/rules/permissions.dart';
import '../models/department.dart';
import '../models/enums.dart';
import '../models/user_profile.dart';
import 'audit_service.dart';

class DepartmentService {
  DepartmentService(this._db, this._audit);

  final FirebaseFirestore _db;
  final AuditService _audit;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(FirestoreCollections.departments);

  Stream<List<Department>> watchAll() => _col
      .orderBy('departmentName')
      .snapshots()
      .map(
        (s) => s.docs
            .map((d) => Department.fromMap(d.id, d.data()))
            .whereType<Department>()
            .toList(),
      );

  Future<bool> _nameTaken(String name, {String? exceptId}) async {
    final snap = await _col
        .where('departmentName', isEqualTo: name.trim())
        .limit(2)
        .get();
    return snap.docs.any((d) => d.id != exceptId);
  }

  Future<String> create(
    UserProfile actor, {
    required String name,
    required DepartmentType type,
  }) async {
    Permissions.require(Permissions.canManageDepartments(actor));
    if (name.trim().isEmpty) {
      throw const AppException('Department name is required.');
    }
    if (await _nameTaken(name)) {
      throw const AppException('A department with this name already exists.');
    }
    final ref = _col.doc();
    final data = Department(
      departmentId: ref.id,
      departmentName: name,
      departmentType: type,
    ).toEditableMap();

    final batch = _db.batch();
    batch.set(ref, {
      'departmentId': ref.id,
      ...data,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    _audit.addToBatch(
      batch,
      actor: actor,
      action: AuditActions.departmentCreated,
      entityType: EntityTypes.department,
      entityId: ref.id,
      newData: data,
    );
    await batch.commit();
    return ref.id;
  }

  /// Updates a department. If the name changed, the denormalized
  /// `departmentName` on its employees and department-head users is refreshed.
  /// (Pass slips keep the name as it was when they were issued — a snapshot.)
  Future<void> update(
    UserProfile actor,
    Department before,
    Department after,
  ) async {
    Permissions.require(Permissions.canManageDepartments(actor));
    if (after.departmentName.trim().isEmpty) {
      throw const AppException('Department name is required.');
    }
    final nameChanged = before.departmentName != after.departmentName.trim();
    if (nameChanged &&
        await _nameTaken(after.departmentName, exceptId: before.departmentId)) {
      throw const AppException('A department with this name already exists.');
    }

    final batch = _db.batch();
    batch.update(_col.doc(before.departmentId), {
      ...after.toEditableMap(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    if (nameChanged) {
      final newName = after.departmentName.trim();
      final employees = await _db
          .collection(FirestoreCollections.employees)
          .where('departmentId', isEqualTo: before.departmentId)
          .get();
      for (final d in employees.docs) {
        batch.update(d.reference, {
          'departmentName': newName,
          'updatedAt': FieldValue.serverTimestamp(),
          'updatedBy': actor.uid,
        });
      }
      final users = await _db
          .collection(FirestoreCollections.users)
          .where('departmentId', isEqualTo: before.departmentId)
          .get();
      for (final d in users.docs) {
        batch.update(d.reference, {
          'departmentName': newName,
          'updatedAt': FieldValue.serverTimestamp(),
          'updatedBy': actor.uid,
        });
      }
    }

    final activeChanged = before.active != after.active;
    _audit.addToBatch(
      batch,
      actor: actor,
      action: activeChanged
          ? (after.active
                ? AuditActions.departmentReactivated
                : AuditActions.departmentDeactivated)
          : AuditActions.departmentUpdated,
      entityType: EntityTypes.department,
      entityId: before.departmentId,
      previousData: before.toEditableMap(),
      newData: after.toEditableMap(),
    );
    await batch.commit();
  }

  Future<void> setActive(UserProfile actor, Department dept, bool active) =>
      update(actor, dept, dept.copyWith(active: active));
}
