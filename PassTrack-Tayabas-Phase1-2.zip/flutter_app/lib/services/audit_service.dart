import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/constants/app_constants.dart';
import '../models/audit_log.dart';
import '../models/user_profile.dart';

class AuditService {
  AuditService(this._db);

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(FirestoreCollections.auditLogs);

  Map<String, dynamic> _entry(
    String id,
    UserProfile actor,
    String action,
    String entityType,
    String entityId,
    Map<String, dynamic>? previousData,
    Map<String, dynamic>? newData,
  ) => {
    'logId': id,
    'action': action,
    'entityType': entityType,
    'entityId': entityId,
    'performedBy': actor.uid,
    'performedByName': actor.fullName,
    'performedByRole': actor.role.value,
    'timestamp': FieldValue.serverTimestamp(),
    'previousData': previousData,
    'newData': newData,
  };

  /// Adds the audit entry to the SAME batch as the action, so the action and
  /// its log are written atomically.
  void addToBatch(
    WriteBatch batch, {
    required UserProfile actor,
    required String action,
    required String entityType,
    required String entityId,
    Map<String, dynamic>? previousData,
    Map<String, dynamic>? newData,
  }) {
    final ref = _col.doc();
    batch.set(
      ref,
      _entry(
        ref.id,
        actor,
        action,
        entityType,
        entityId,
        previousData,
        newData,
      ),
    );
  }

  void addToTransaction(
    Transaction tx, {
    required UserProfile actor,
    required String action,
    required String entityType,
    required String entityId,
    Map<String, dynamic>? previousData,
    Map<String, dynamic>? newData,
  }) {
    final ref = _col.doc();
    tx.set(
      ref,
      _entry(
        ref.id,
        actor,
        action,
        entityType,
        entityId,
        previousData,
        newData,
      ),
    );
  }

  Stream<List<AuditLog>> watchRecent({int limit = 200, String? entityType}) {
    Query<Map<String, dynamic>> q = _col;
    if (entityType != null) q = q.where('entityType', isEqualTo: entityType);
    return q
        .orderBy('timestamp', descending: true)
        .limit(limit)
        .snapshots()
        .map(
          (s) => s.docs.map((d) => AuditLog.fromMap(d.id, d.data())).toList(),
        );
  }
}
