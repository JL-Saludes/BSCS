import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/config/working_hours.dart';
import '../core/constants/app_constants.dart';
import '../core/constants/audit_actions.dart';
import '../core/errors/app_exception.dart';
import '../core/rules/permissions.dart';
import '../models/user_profile.dart';
import 'audit_service.dart';

class SettingsService {
  SettingsService(this._db, this._audit);

  final FirebaseFirestore _db;
  final AuditService _audit;

  DocumentReference<Map<String, dynamic>> get _hoursRef =>
      _db.collection(FirestoreCollections.settings).doc('working_hours');

  Stream<WorkingHours> watchWorkingHours() => _hoursRef.snapshots().map((s) {
    final d = s.data();
    return (s.exists && d != null)
        ? WorkingHours.fromMap(d)
        : WorkingHours.standard;
  });

  Future<void> saveWorkingHours(UserProfile actor, WorkingHours hours) async {
    Permissions.require(Permissions.canManageSettings(actor));
    if (hours.startMinute < 0 ||
        hours.endMinute > 1439 ||
        hours.startMinute >= hours.endMinute) {
      throw const AppException('Working hours are invalid.');
    }
    final before = (await _hoursRef.get()).data();
    final batch = _db.batch();
    batch.set(_hoursRef, {
      ...hours.toMap(),
      'updatedAt': FieldValue.serverTimestamp(),
      'updatedBy': actor.uid,
    });
    _audit.addToBatch(
      batch,
      actor: actor,
      action: AuditActions.settingsUpdated,
      entityType: EntityTypes.settings,
      entityId: 'working_hours',
      previousData: before == null
          ? null
          : {
              'startMinute': before['startMinute'],
              'endMinute': before['endMinute'],
            },
      newData: hours.toMap(),
    );
    await batch.commit();
  }
}
