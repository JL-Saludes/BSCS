import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/constants/app_constants.dart';
import '../core/utils/manila_time.dart';
import '../models/pass_slip.dart';
import '../models/user_profile.dart';
import '../models/user_role.dart';

/// Phase 2 creates notification documents inside the approval transaction.
/// Reading, mark-as-read and push (FCM) are added in Phase 6.
class NotificationService {
  NotificationService(this._db);

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(FirestoreCollections.notifications);

  void _add(
    Transaction tx, {
    required UserProfile actor,
    required String type,
    required String title,
    required String message,
    required String passSlipId,
    String? targetRole,
    String? targetUserId,
  }) {
    final ref = _col.doc();
    tx.set(ref, {
      'notificationId': ref.id,
      'type': type,
      'title': title,
      'message': message,
      'targetRole': targetRole,
      'targetUserId': targetUserId,
      'passSlipId': passSlipId,
      'createdBy': actor.uid,
      'createdAt': FieldValue.serverTimestamp(),
      'readBy': <String>[],
    });
  }

  void passApprovedForGuards(
    Transaction tx, {
    required UserProfile actor,
    required PassSlip pass,
  }) {
    _add(
      tx,
      actor: actor,
      type: 'pass_approved',
      title: 'Pass approved',
      message:
          'Approved pass: ${pass.employeeName} is authorized to leave from '
          '${pass.departmentName}. Expected return: '
          '${ManilaTime.formatTime(pass.expectedReturnTime)}.',
      passSlipId: pass.passSlipId,
      targetRole: UserRole.guard.value,
    );
  }

  void passRejectedForRequester(
    Transaction tx, {
    required UserProfile actor,
    required PassSlip pass,
    required String reason,
  }) {
    _add(
      tx,
      actor: actor,
      type: 'pass_rejected',
      title: 'Pass rejected',
      message:
          'The pass slip for ${pass.employeeName} was rejected. Reason: $reason',
      passSlipId: pass.passSlipId,
      targetUserId: pass.requestedBy,
    );
  }
}
