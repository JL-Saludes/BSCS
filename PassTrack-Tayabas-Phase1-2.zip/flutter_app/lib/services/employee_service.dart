import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/constants/app_constants.dart';
import '../core/constants/audit_actions.dart';
import '../core/errors/app_exception.dart';
import '../core/rules/permissions.dart';
import '../models/employee.dart';
import '../models/enums.dart';
import '../models/user_profile.dart';
import '../models/user_role.dart';
import 'audit_service.dart';

class EmployeeService {
  EmployeeService(this._db, this._audit);

  final FirebaseFirestore _db;
  final AuditService _audit;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(FirestoreCollections.employees);

  /// Role-aware query that matches the Firestore rules:
  /// Admin → all, Department Head → own department, Guard → none.
  Stream<List<Employee>> watchVisible(UserProfile viewer) {
    Query<Map<String, dynamic>> q = _col;
    switch (viewer.role) {
      case UserRole.admin:
        break;
      case UserRole.departmentHead:
        final dept = viewer.departmentId;
        if (dept == null) return Stream.value(const []);
        q = q.where('departmentId', isEqualTo: dept);
      case UserRole.guard:
        return Stream.value(const []);
    }
    return q
        .orderBy('fullName')
        .snapshots()
        .map(
          (s) => s.docs
              .map((d) => Employee.fromMap(d.id, d.data()))
              .whereType<Employee>()
              .toList(),
        );
  }

  Future<bool> _numberTaken(String number, {String? exceptId}) async {
    final snap = await _col
        .where('employeeNumber', isEqualTo: number.trim())
        .limit(2)
        .get();
    return snap.docs.any((d) => d.id != exceptId);
  }

  void _validate(Employee e) {
    if (e.firstName.trim().isEmpty ||
        e.lastName.trim().isEmpty ||
        e.employeeNumber.trim().isEmpty ||
        e.position.trim().isEmpty ||
        e.departmentId.isEmpty) {
      throw const AppException('Please complete all required employee fields.');
    }
  }

  Future<String> create(UserProfile actor, Employee draft) async {
    Permissions.require(Permissions.canManageEmployees(actor));
    _validate(draft);
    if (await _numberTaken(draft.employeeNumber)) {
      throw const AppException('This employee number is already in use.');
    }
    final ref = _col.doc();
    final data = draft.toEditableMap();

    final batch = _db.batch();
    batch.set(ref, {
      'employeeId': ref.id,
      ...data,
      if (draft.isTestData) 'isTestData': true,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      'createdBy': actor.uid,
      'updatedBy': actor.uid,
    });
    _audit.addToBatch(
      batch,
      actor: actor,
      action: AuditActions.employeeCreated,
      entityType: EntityTypes.employee,
      entityId: ref.id,
      newData: data,
    );
    await batch.commit();
    return ref.id;
  }

  Future<void> update(
    UserProfile actor,
    Employee before,
    Employee after,
  ) async {
    Permissions.require(Permissions.canManageEmployees(actor));
    _validate(after);
    if (before.employeeNumber != after.employeeNumber.trim() &&
        await _numberTaken(after.employeeNumber, exceptId: before.employeeId)) {
      throw const AppException('This employee number is already in use.');
    }
    final statusChanged = before.employmentStatus != after.employmentStatus;

    final batch = _db.batch();
    batch.update(_col.doc(before.employeeId), {
      ...after.toEditableMap(),
      'updatedAt': FieldValue.serverTimestamp(),
      'updatedBy': actor.uid,
    });
    _audit.addToBatch(
      batch,
      actor: actor,
      action: statusChanged
          ? (after.isActive
                ? AuditActions.employeeReactivated
                : AuditActions.employeeDeactivated)
          : AuditActions.employeeUpdated,
      entityType: EntityTypes.employee,
      entityId: before.employeeId,
      previousData: before.toEditableMap(),
      newData: after.toEditableMap(),
    );
    await batch.commit();
  }

  /// "Delete" = deactivate. History stays intact; the employee simply stops
  /// appearing in the new-pass picker.
  Future<void> setStatus(
    UserProfile actor,
    Employee employee,
    EmploymentStatus status,
  ) => update(actor, employee, employee.copyWith(employmentStatus: status));
}
