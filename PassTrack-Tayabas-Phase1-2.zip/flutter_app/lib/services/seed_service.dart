import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/config/working_hours.dart';
import '../core/constants/app_constants.dart';
import '../core/constants/audit_actions.dart';
import '../core/rules/permissions.dart';
import '../models/enums.dart';
import '../models/user_profile.dart';
import 'audit_service.dart';

class _SeedDept {
  const _SeedDept(this.id, this.name, this.type);
  final String id;
  final String name;
  final DepartmentType type;
}

class _SeedEmployee {
  const _SeedEmployee(
    this.id,
    this.number,
    this.first,
    this.middle,
    this.last,
    this.deptId,
    this.type,
    this.position,
  );
  final String id, number, first, middle, last, deptId, position;
  final EmployeeType type;
}

/// TEST/SEED DATA. Employees are flagged `isTestData: true` so they can be
/// removed from the app with one tap before go-live.
class SeedService {
  SeedService(this._db, this._audit);

  final FirebaseFirestore _db;
  final AuditService _audit;

  static const _departments = [
    _SeedDept('bscs', 'BS Computer Science', DepartmentType.academic),
    _SeedDept('tourism', 'Tourism', DepartmentType.academic),
    _SeedDept('entrepreneurship', 'Entrepreneurship', DepartmentType.academic),
    _SeedDept('baculturearts', 'BA Culture and Arts', DepartmentType.academic),
    _SeedDept(
      'admin',
      'Administration / Non-Teaching',
      DepartmentType.nonTeaching,
    ),
  ];

  static const _employees = [
    _SeedEmployee(
      'seed_emp_01',
      'TEST-001',
      'Juan',
      'Santos',
      'Dela Cruz',
      'bscs',
      EmployeeType.teaching,
      'Instructor I',
    ),
    _SeedEmployee(
      'seed_emp_02',
      'TEST-002',
      'Maria',
      'Reyes',
      'Garcia',
      'bscs',
      EmployeeType.teaching,
      'Assistant Professor',
    ),
    _SeedEmployee(
      'seed_emp_03',
      'TEST-003',
      'Pedro',
      'Lim',
      'Bautista',
      'tourism',
      EmployeeType.teaching,
      'Instructor II',
    ),
    _SeedEmployee(
      'seed_emp_04',
      'TEST-004',
      'Ana',
      'Cruz',
      'Mendoza',
      'entrepreneurship',
      EmployeeType.teaching,
      'Instructor I',
    ),
    _SeedEmployee(
      'seed_emp_05',
      'TEST-005',
      'Carlo',
      'Ramos',
      'Villanueva',
      'baculturearts',
      EmployeeType.teaching,
      'Associate Professor',
    ),
    _SeedEmployee(
      'seed_emp_06',
      'TEST-006',
      'Liza',
      'Torres',
      'Aquino',
      'admin',
      EmployeeType.nonTeaching,
      'Registrar Staff',
    ),
    _SeedEmployee(
      'seed_emp_07',
      'TEST-007',
      'Mark',
      'Diaz',
      'Castillo',
      'admin',
      EmployeeType.nonTeaching,
      'Accounting Clerk',
    ),
    _SeedEmployee(
      'seed_emp_08',
      'TEST-008',
      'Rosa',
      'Navarro',
      'Pascual',
      'admin',
      EmployeeType.nonTeaching,
      'Administrative Aide',
    ),
  ];

  Future<String> seed(UserProfile actor) async {
    Permissions.require(Permissions.canManageEmployees(actor));
    final deptCol = _db.collection(FirestoreCollections.departments);
    final empCol = _db.collection(FirestoreCollections.employees);
    final hoursRef = _db
        .collection(FirestoreCollections.settings)
        .doc('working_hours');

    // Step 1: departments + working hours (employee rules need departments to
    // exist BEFORE the employee batch, so this is a separate commit).
    final existingDepts = (await deptCol.get()).docs.map((d) => d.id).toSet();
    final b1 = _db.batch();
    var newDepts = 0;
    for (final d in _departments) {
      if (existingDepts.contains(d.id)) continue;
      b1.set(deptCol.doc(d.id), {
        'departmentId': d.id,
        'departmentName': d.name,
        'departmentType': d.type.value,
        'departmentHeadUserId': null,
        'active': true,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      newDepts++;
    }
    var hoursCreated = false;
    if (!(await hoursRef.get()).exists) {
      b1.set(hoursRef, {
        ...WorkingHours.standard.toMap(),
        'updatedAt': FieldValue.serverTimestamp(),
        'updatedBy': actor.uid,
      });
      hoursCreated = true;
    }
    if (newDepts > 0 || hoursCreated) await b1.commit();

    // Step 2: sample employees.
    final existingEmps =
        (await empCol.where('isTestData', isEqualTo: true).get()).docs
            .map((d) => d.id)
            .toSet();
    final nameById = {for (final d in _departments) d.id: d.name};
    final b2 = _db.batch();
    var newEmps = 0;
    for (final e in _employees) {
      if (existingEmps.contains(e.id)) continue;
      final fullName = '${e.first} ${e.middle} ${e.last}';
      b2.set(empCol.doc(e.id), {
        'employeeId': e.id,
        'employeeNumber': e.number,
        'fullName': fullName,
        'firstName': e.first,
        'middleName': e.middle,
        'lastName': e.last,
        'departmentId': e.deptId,
        'departmentName': nameById[e.deptId],
        'employeeType': e.type.value,
        'position': e.position,
        'contactNumber': '',
        'email': '',
        'employmentStatus': EmploymentStatus.active.value,
        'isTestData': true,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'createdBy': actor.uid,
        'updatedBy': actor.uid,
      });
      newEmps++;
    }
    if (newEmps > 0) {
      _audit.addToBatch(
        b2,
        actor: actor,
        action: AuditActions.seedLoaded,
        entityType: EntityTypes.employee,
        entityId: 'seed',
        newData: {'employees': newEmps, 'departments': newDepts},
      );
      await b2.commit();
    }
    return 'Added $newDepts department(s) and $newEmps test employee(s).';
  }

  /// Deletes only employees flagged as test data. Departments and settings
  /// are real configuration and are kept.
  Future<String> removeTestData(UserProfile actor) async {
    Permissions.require(Permissions.canManageEmployees(actor));
    final snap = await _db
        .collection(FirestoreCollections.employees)
        .where('isTestData', isEqualTo: true)
        .get();
    if (snap.docs.isEmpty) return 'No test employees found.';
    final batch = _db.batch();
    for (final d in snap.docs) {
      batch.delete(d.reference);
    }
    _audit.addToBatch(
      batch,
      actor: actor,
      action: AuditActions.seedRemoved,
      entityType: EntityTypes.employee,
      entityId: 'seed',
      newData: {'employees': snap.docs.length},
    );
    await batch.commit();
    return 'Removed ${snap.docs.length} test employee(s).';
  }
}
