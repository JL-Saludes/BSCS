import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/errors/error_mapper.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/data_providers.dart';

class AdminHomePage extends ConsumerStatefulWidget {
  const AdminHomePage({super.key});

  @override
  ConsumerState<AdminHomePage> createState() => _AdminHomePageState();
}

class _AdminHomePageState extends ConsumerState<AdminHomePage> {
  bool _busy = false;

  Future<void> _run(Future<String> Function() action) async {
    setState(() => _busy = true);
    String message;
    try {
      message = await action();
    } catch (e) {
      message = friendlyError(e);
    }
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final profile = ref.watch(userProfileProvider).asData?.value;
    final departments = ref.watch(departmentsProvider);
    final employees = ref.watch(employeesProvider);
    final hours = ref.watch(workingHoursProvider);

    String count<T>(AsyncValue<List<T>> v) => v.when(
      data: (l) => '${l.length}',
      loading: () => '…',
      error: (e, _) => friendlyError(e),
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin (Phase 2 console)'),
        actions: [
          IconButton(
            tooltip: 'Sign out',
            icon: const Icon(Icons.logout),
            onPressed: () => ref.read(authServiceProvider).signOut(),
          ),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 640),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(profile?.fullName ?? ''),
                  subtitle: Text(profile?.role.label ?? ''),
                ),
              ),
              const SizedBox(height: 8),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Live data',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 8),
                      Text('Departments: ${count(departments)}'),
                      Text('Employees: ${count(employees)}'),
                      Text(
                        'Working hours: ${hours.asData?.value.label ?? '…'}',
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: _busy || profile == null
                    ? null
                    : () => _run(
                        () => ref.read(seedServiceProvider).seed(profile),
                      ),
                icon: const Icon(Icons.dataset),
                label: const Text('Load seed / test data'),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: _busy || profile == null
                    ? null
                    : () => _run(
                        () => ref
                            .read(seedServiceProvider)
                            .removeTestData(profile),
                      ),
                icon: const Icon(Icons.delete_sweep),
                label: const Text('Remove test employees'),
              ),
              if (_busy)
                const Padding(
                  padding: EdgeInsets.only(top: 16),
                  child: LinearProgressIndicator(),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
