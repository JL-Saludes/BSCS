import 'package:flutter/material.dart';

import '../../../widgets/role_home_scaffold.dart';

class DepartmentHeadHomePage extends StatelessWidget {
  const DepartmentHeadHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const RoleHomeScaffold(
      title: 'Department Head',
      upcoming: [
        'Department employees',
        'Create pass slips and approve teaching employees',
        'Department dashboard and history',
      ],
    );
  }
}
