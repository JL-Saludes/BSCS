import 'package:flutter/material.dart';

import '../../../widgets/role_home_scaffold.dart';

class GuardHomePage extends StatelessWidget {
  const GuardHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const RoleHomeScaffold(
      title: 'Guard Dashboard',
      upcoming: [
        'Approved passes ready for Time Out',
        'Currently out and overdue monitoring',
        'Time In recording',
      ],
    );
  }
}
