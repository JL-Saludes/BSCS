import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/config/working_hours.dart';
import '../models/department.dart';
import '../models/employee.dart';
import '../models/pass_slip.dart';
import '../models/user_profile.dart';
import '../models/user_role.dart';
import '../services/audit_service.dart';
import '../services/department_service.dart';
import '../services/employee_service.dart';
import '../services/notification_service.dart';
import '../services/pass_slip_service.dart';
import '../services/seed_service.dart';
import '../services/settings_service.dart';
import '../services/user_service.dart';
import 'auth_provider.dart';
import 'firebase_providers.dart';

final auditServiceProvider = Provider(
  (ref) => AuditService(ref.watch(firestoreProvider)),
);

final notificationServiceProvider = Provider(
  (ref) => NotificationService(ref.watch(firestoreProvider)),
);

final settingsServiceProvider = Provider(
  (ref) => SettingsService(
    ref.watch(firestoreProvider),
    ref.watch(auditServiceProvider),
  ),
);

final departmentServiceProvider = Provider(
  (ref) => DepartmentService(
    ref.watch(firestoreProvider),
    ref.watch(auditServiceProvider),
  ),
);

final employeeServiceProvider = Provider(
  (ref) => EmployeeService(
    ref.watch(firestoreProvider),
    ref.watch(auditServiceProvider),
  ),
);

final userServiceProvider = Provider(
  (ref) => UserService(
    ref.watch(firestoreProvider),
    ref.watch(firebaseAuthProvider),
    ref.watch(auditServiceProvider),
  ),
);

final passSlipServiceProvider = Provider(
  (ref) => PassSlipService(
    ref.watch(firestoreProvider),
    ref.watch(auditServiceProvider),
    ref.watch(notificationServiceProvider),
  ),
);

final seedServiceProvider = Provider(
  (ref) => SeedService(
    ref.watch(firestoreProvider),
    ref.watch(auditServiceProvider),
  ),
);

/// Signed-in profile, or null. Streams below rebuild when it changes, so they
/// never keep listening after sign-out.
final _currentProfileProvider = Provider<UserProfile?>(
  (ref) => ref.watch(userProfileProvider).asData?.value,
);

final departmentsProvider = StreamProvider<List<Department>>((ref) {
  if (ref.watch(_currentProfileProvider) == null) return Stream.value(const []);
  return ref.watch(departmentServiceProvider).watchAll();
});

final employeesProvider = StreamProvider<List<Employee>>((ref) {
  final p = ref.watch(_currentProfileProvider);
  if (p == null) return Stream.value(const []);
  return ref.watch(employeeServiceProvider).watchVisible(p);
});

final passSlipsProvider = StreamProvider<List<PassSlip>>((ref) {
  final p = ref.watch(_currentProfileProvider);
  if (p == null) return Stream.value(const []);
  return ref.watch(passSlipServiceProvider).watchVisible(p);
});

/// Admin only.
final usersProvider = StreamProvider<List<UserProfile>>((ref) {
  final p = ref.watch(_currentProfileProvider);
  if (p == null || p.role != UserRole.admin) return Stream.value(const []);
  return ref.watch(userServiceProvider).watchAll();
});

final workingHoursProvider = StreamProvider<WorkingHours>((ref) {
  if (ref.watch(_currentProfileProvider) == null) {
    return Stream.value(WorkingHours.standard);
  }
  return ref.watch(settingsServiceProvider).watchWorkingHours();
});
