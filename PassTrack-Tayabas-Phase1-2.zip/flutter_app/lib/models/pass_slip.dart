import 'enums.dart';
import 'model_utils.dart';

class PassSlip {
  const PassSlip({
    required this.passSlipId,
    required this.employeeId,
    required this.employeeNumber,
    required this.employeeName,
    required this.departmentId,
    required this.departmentName,
    required this.employeeType,
    required this.date,
    required this.requestedTimeOut,
    required this.expectedReturnTime,
    required this.reason,
    required this.destination,
    required this.requestedBy,
    required this.requestedByName,
    required this.status,
    this.actualTimeOut,
    this.actualTimeIn,
    this.approvedBy,
    this.approvedByName,
    this.approvedAt,
    this.rejectedBy,
    this.rejectedByName,
    this.rejectedAt,
    this.rejectionReason,
    this.cancelledBy,
    this.cancelledByName,
    this.cancelledAt,
    this.cancellationReason,
    this.guardTimeOutBy,
    this.guardTimeOutByName,
    this.guardTimeInBy,
    this.guardTimeInByName,
    this.createdAt,
    this.updatedAt,
  });

  final String passSlipId;
  final String employeeId;
  final String employeeNumber;
  final String employeeName;
  final String departmentId;
  final String departmentName;
  final EmployeeType employeeType;

  /// Manila midnight (as an instant) of the pass date.
  final DateTime date;
  final DateTime requestedTimeOut;
  final DateTime expectedReturnTime;
  final DateTime? actualTimeOut;
  final DateTime? actualTimeIn;
  final String reason;
  final String destination;
  final String requestedBy;
  final String requestedByName;
  final String? approvedBy;
  final String? approvedByName;
  final DateTime? approvedAt;
  final String? rejectedBy;
  final String? rejectedByName;
  final DateTime? rejectedAt;
  final String? rejectionReason;
  final String? cancelledBy;
  final String? cancelledByName;
  final DateTime? cancelledAt;
  final String? cancellationReason;
  final String? guardTimeOutBy;
  final String? guardTimeOutByName;
  final String? guardTimeInBy;
  final String? guardTimeInByName;
  final PassStatus status;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  /// Actual time spent outside (only once the employee has returned).
  Duration? get actualDuration =>
      (actualTimeOut != null && actualTimeIn != null)
      ? actualTimeIn!.difference(actualTimeOut!)
      : null;

  bool get returnedLate =>
      actualTimeIn != null && actualTimeIn!.isAfter(expectedReturnTime);

  static PassSlip? fromMap(String id, Map<String, dynamic> d) {
    final status = PassStatus.fromValue(d['status'] as String?);
    final type = EmployeeType.fromValue(d['employeeType'] as String?);
    final date = readDate(d['date']);
    final out = readDate(d['requestedTimeOut']);
    final ret = readDate(d['expectedReturnTime']);
    if (status == null ||
        type == null ||
        date == null ||
        out == null ||
        ret == null) {
      return null;
    }
    return PassSlip(
      passSlipId: id,
      employeeId: readString(d['employeeId']),
      employeeNumber: readString(d['employeeNumber']),
      employeeName: readString(d['employeeName']),
      departmentId: readString(d['departmentId']),
      departmentName: readString(d['departmentName']),
      employeeType: type,
      date: date,
      requestedTimeOut: out,
      expectedReturnTime: ret,
      actualTimeOut: readDate(d['actualTimeOut']),
      actualTimeIn: readDate(d['actualTimeIn']),
      reason: readString(d['reason']),
      destination: readString(d['destination']),
      requestedBy: readString(d['requestedBy']),
      requestedByName: readString(d['requestedByName']),
      approvedBy: d['approvedBy'] as String?,
      approvedByName: d['approvedByName'] as String?,
      approvedAt: readDate(d['approvedAt']),
      rejectedBy: d['rejectedBy'] as String?,
      rejectedByName: d['rejectedByName'] as String?,
      rejectedAt: readDate(d['rejectedAt']),
      rejectionReason: d['rejectionReason'] as String?,
      cancelledBy: d['cancelledBy'] as String?,
      cancelledByName: d['cancelledByName'] as String?,
      cancelledAt: readDate(d['cancelledAt']),
      cancellationReason: d['cancellationReason'] as String?,
      guardTimeOutBy: d['guardTimeOutBy'] as String?,
      guardTimeOutByName: d['guardTimeOutByName'] as String?,
      guardTimeInBy: d['guardTimeInBy'] as String?,
      guardTimeInByName: d['guardTimeInByName'] as String?,
      status: status,
      createdAt: readDate(d['createdAt']),
      updatedAt: readDate(d['updatedAt']),
    );
  }
}
