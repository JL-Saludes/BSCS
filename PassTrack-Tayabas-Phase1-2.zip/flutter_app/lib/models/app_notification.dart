import 'model_utils.dart';

/// Addressed either to one user (`targetUserId`) or to every user of a role
/// (`targetRole`, with `targetUserId == null`). Per-user read state is `readBy`.
class AppNotification {
  const AppNotification({
    required this.notificationId,
    required this.type,
    required this.title,
    required this.message,
    this.targetRole,
    this.targetUserId,
    this.passSlipId,
    this.createdBy,
    this.createdAt,
    this.readBy = const [],
  });

  final String notificationId;
  final String type;
  final String title;
  final String message;
  final String? targetRole;
  final String? targetUserId;
  final String? passSlipId;
  final String? createdBy;
  final DateTime? createdAt;
  final List<String> readBy;

  bool isReadBy(String uid) => readBy.contains(uid);

  static AppNotification fromMap(String id, Map<String, dynamic> d) =>
      AppNotification(
        notificationId: id,
        type: readString(d['type']),
        title: readString(d['title']),
        message: readString(d['message']),
        targetRole: d['targetRole'] as String?,
        targetUserId: d['targetUserId'] as String?,
        passSlipId: d['passSlipId'] as String?,
        createdBy: d['createdBy'] as String?,
        createdAt: readDate(d['createdAt']),
        readBy: ((d['readBy'] as List?) ?? const [])
            .whereType<String>()
            .toList(),
      );
}
