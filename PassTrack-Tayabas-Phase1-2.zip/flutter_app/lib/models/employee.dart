import 'enums.dart';
import 'model_utils.dart';

class Employee {
  const Employee({
    required this.employeeId,
    required this.employeeNumber,
    required this.firstName,
    this.middleName = '',
    required this.lastName,
    required this.departmentId,
    required this.departmentName,
    required this.employeeType,
    required this.position,
    this.contactNumber = '',
    this.email = '',
    this.employmentStatus = EmploymentStatus.active,
    this.isTestData = false,
    this.createdAt,
    this.updatedAt,
    this.createdBy,
    this.updatedBy,
  });

  final String employeeId;
  final String employeeNumber;
  final String firstName;
  final String middleName;
  final String lastName;
  final String departmentId;
  final String departmentName;
  final EmployeeType employeeType;
  final String position;
  final String contactNumber;
  final String email;
  final EmploymentStatus employmentStatus;
  final bool isTestData;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? createdBy;
  final String? updatedBy;

  String get fullName => buildFullName(firstName, middleName, lastName);
  bool get isActive => employmentStatus == EmploymentStatus.active;

  static String buildFullName(String first, String middle, String last) => [
    first.trim(),
    middle.trim(),
    last.trim(),
  ].where((s) => s.isNotEmpty).join(' ');

  Employee copyWith({
    String? employeeNumber,
    String? firstName,
    String? middleName,
    String? lastName,
    String? departmentId,
    String? departmentName,
    EmployeeType? employeeType,
    String? position,
    String? contactNumber,
    String? email,
    EmploymentStatus? employmentStatus,
  }) => Employee(
    employeeId: employeeId,
    employeeNumber: employeeNumber ?? this.employeeNumber,
    firstName: firstName ?? this.firstName,
    middleName: middleName ?? this.middleName,
    lastName: lastName ?? this.lastName,
    departmentId: departmentId ?? this.departmentId,
    departmentName: departmentName ?? this.departmentName,
    employeeType: employeeType ?? this.employeeType,
    position: position ?? this.position,
    contactNumber: contactNumber ?? this.contactNumber,
    email: email ?? this.email,
    employmentStatus: employmentStatus ?? this.employmentStatus,
    isTestData: isTestData,
    createdAt: createdAt,
    updatedAt: updatedAt,
    createdBy: createdBy,
    updatedBy: updatedBy,
  );

  /// The fields an Admin may edit. Must match `firestore.rules`.
  Map<String, dynamic> toEditableMap() => {
    'employeeNumber': employeeNumber.trim(),
    'fullName': fullName,
    'firstName': firstName.trim(),
    'middleName': middleName.trim(),
    'lastName': lastName.trim(),
    'departmentId': departmentId,
    'departmentName': departmentName,
    'employeeType': employeeType.value,
    'position': position.trim(),
    'contactNumber': contactNumber.trim(),
    'email': email.trim(),
    'employmentStatus': employmentStatus.value,
  };

  static Employee? fromMap(String id, Map<String, dynamic> d) {
    final type = EmployeeType.fromValue(d['employeeType'] as String?);
    final status = EmploymentStatus.fromValue(d['employmentStatus'] as String?);
    if (type == null || status == null) return null;
    return Employee(
      employeeId: id,
      employeeNumber: readString(d['employeeNumber']),
      firstName: readString(d['firstName']),
      middleName: readString(d['middleName']),
      lastName: readString(d['lastName']),
      departmentId: readString(d['departmentId']),
      departmentName: readString(d['departmentName']),
      employeeType: type,
      position: readString(d['position']),
      contactNumber: readString(d['contactNumber']),
      email: readString(d['email']),
      employmentStatus: status,
      isTestData: d['isTestData'] == true,
      createdAt: readDate(d['createdAt']),
      updatedAt: readDate(d['updatedAt']),
      createdBy: d['createdBy'] as String?,
      updatedBy: d['updatedBy'] as String?,
    );
  }
}
