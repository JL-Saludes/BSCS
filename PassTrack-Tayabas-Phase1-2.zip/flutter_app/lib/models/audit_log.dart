import 'model_utils.dart';

class AuditLog {
  const AuditLog({
    required this.logId,
    required this.action,
    required this.entityType,
    required this.entityId,
    required this.performedBy,
    required this.performedByName,
    required this.performedByRole,
    this.timestamp,
    this.previousData,
    this.newData,
  });

  final String logId;
  final String action;
  final String entityType;
  final String entityId;
  final String performedBy;
  final String performedByName;
  final String performedByRole;
  final DateTime? timestamp;
  final Map<String, dynamic>? previousData;
  final Map<String, dynamic>? newData;

  static AuditLog fromMap(String id, Map<String, dynamic> d) => AuditLog(
    logId: id,
    action: readString(d['action']),
    entityType: readString(d['entityType']),
    entityId: readString(d['entityId']),
    performedBy: readString(d['performedBy']),
    performedByName: readString(d['performedByName']),
    performedByRole: readString(d['performedByRole']),
    timestamp: readDate(d['timestamp']),
    previousData: (d['previousData'] as Map?)?.cast<String, dynamic>(),
    newData: (d['newData'] as Map?)?.cast<String, dynamic>(),
  );
}
