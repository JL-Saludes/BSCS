enum EmployeeType {
  teaching('Teaching'),
  nonTeaching('Non-Teaching');

  const EmployeeType(this.value);
  final String value;

  static EmployeeType? fromValue(String? v) {
    for (final e in values) {
      if (e.value == v) return e;
    }
    return null;
  }
}

enum EmploymentStatus {
  active('Active'),
  inactive('Inactive');

  const EmploymentStatus(this.value);
  final String value;

  static EmploymentStatus? fromValue(String? v) {
    for (final e in values) {
      if (e.value == v) return e;
    }
    return null;
  }
}

enum DepartmentType {
  academic('Academic'),
  nonTeaching('Non-Teaching');

  const DepartmentType(this.value);
  final String value;

  static DepartmentType? fromValue(String? v) {
    for (final e in values) {
      if (e.value == v) return e;
    }
    return null;
  }
}

/// Pending → Approved → Out → Completed, with Rejected / Cancelled as exits.
enum PassStatus {
  pending('Pending'),
  approved('Approved'),
  rejected('Rejected'),
  out('Out'),
  completed('Completed'),
  cancelled('Cancelled');

  const PassStatus(this.value);
  final String value;

  bool get isFinal =>
      this == rejected || this == completed || this == cancelled;

  static PassStatus? fromValue(String? v) {
    for (final e in values) {
      if (e.value == v) return e;
    }
    return null;
  }
}
