import 'package:cloud_firestore/cloud_firestore.dart';

DateTime? readDate(Object? v) => v is Timestamp ? v.toDate() : null;

Timestamp? writeDate(DateTime? d) => d == null ? null : Timestamp.fromDate(d);

String readString(Object? v, [String fallback = '']) =>
    v is String ? v : fallback;
