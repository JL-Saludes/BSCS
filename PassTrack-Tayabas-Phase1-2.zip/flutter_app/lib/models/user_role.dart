enum UserRole {
  admin('admin', 'Administrator', '/admin'),
  departmentHead('departmentHead', 'Department Head', '/department-head'),
  guard('guard', 'Guard / Security', '/guard');

  const UserRole(this.value, this.label, this.homePath);

  /// Stored in Firestore `users/{uid}.role`.
  final String value;
  final String label;
  final String homePath;

  static UserRole? fromValue(String? value) {
    for (final role in UserRole.values) {
      if (role.value == value) return role;
    }
    return null;
  }
}
