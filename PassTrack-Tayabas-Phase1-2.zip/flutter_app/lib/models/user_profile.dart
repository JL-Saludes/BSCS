import 'package:cloud_firestore/cloud_firestore.dart';

import 'user_role.dart';

class UserProfile {
  const UserProfile({
    required this.uid,
    required this.email,
    required this.fullName,
    required this.role,
    required this.active,
    this.departmentId,
    this.departmentName,
    this.createdAt,
    this.updatedAt,
    this.createdBy,
  });

  final String uid;
  final String email;
  final String fullName;
  final UserRole role;
  final bool active;
  final String? departmentId;
  final String? departmentName;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? createdBy;

  /// Returns null when the document has no valid role, so a malformed
  /// profile can never be treated as authorized.
  static UserProfile? fromMap(String uid, Map<String, dynamic> data) {
    final role = UserRole.fromValue(data['role'] as String?);
    if (role == null) return null;
    return UserProfile(
      uid: uid,
      email: (data['email'] as String?) ?? '',
      fullName: (data['fullName'] as String?) ?? '',
      role: role,
      active: data['active'] == true,
      departmentId: data['departmentId'] as String?,
      departmentName: data['departmentName'] as String?,
      createdAt: _toDate(data['createdAt']),
      updatedAt: _toDate(data['updatedAt']),
      createdBy: data['createdBy'] as String?,
    );
  }

  static DateTime? _toDate(Object? v) => v is Timestamp ? v.toDate() : null;
}
