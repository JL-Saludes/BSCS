import 'enums.dart';
import 'model_utils.dart';

class Department {
  const Department({
    required this.departmentId,
    required this.departmentName,
    required this.departmentType,
    this.departmentHeadUserId,
    this.active = true,
    this.createdAt,
    this.updatedAt,
  });

  final String departmentId;
  final String departmentName;
  final DepartmentType departmentType;
  final String? departmentHeadUserId;
  final bool active;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Department copyWith({
    String? departmentName,
    DepartmentType? departmentType,
    String? departmentHeadUserId,
    bool? active,
  }) => Department(
    departmentId: departmentId,
    departmentName: departmentName ?? this.departmentName,
    departmentType: departmentType ?? this.departmentType,
    departmentHeadUserId: departmentHeadUserId ?? this.departmentHeadUserId,
    active: active ?? this.active,
    createdAt: createdAt,
    updatedAt: updatedAt,
  );

  Map<String, dynamic> toEditableMap() => {
    'departmentName': departmentName.trim(),
    'departmentType': departmentType.value,
    'departmentHeadUserId': departmentHeadUserId,
    'active': active,
  };

  static Department? fromMap(String id, Map<String, dynamic> d) {
    final type = DepartmentType.fromValue(d['departmentType'] as String?);
    if (type == null) return null;
    return Department(
      departmentId: id,
      departmentName: readString(d['departmentName']),
      departmentType: type,
      departmentHeadUserId: d['departmentHeadUserId'] as String?,
      active: d['active'] != false,
      createdAt: readDate(d['createdAt']),
      updatedAt: readDate(d['updatedAt']),
    );
  }
}
