import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/user_profile.dart';
import 'routes.dart';

/// Pure function (easy to unit test). Returns the location to redirect to,
/// or null to allow navigation to [location].
String? resolveRedirect({
  required AsyncValue<User?> auth,
  required AsyncValue<UserProfile?> profile,
  required String location,
}) {
  String? go(String target) => location == target ? null : target;

  if (auth.isLoading) return go(Routes.splash);
  if (auth.hasError) return go(Routes.login);

  final user = auth.asData?.value;
  if (user == null) return go(Routes.login);

  if (profile.isLoading) return go(Routes.splash);
  if (profile.hasError) return go(Routes.accountIssue);

  final p = profile.asData?.value;
  if (p == null || !p.active) return go(Routes.accountIssue);

  // Signed in with a valid, active profile: users may only stay inside
  // their own role area.
  final home = p.role.homePath;
  final inOwnArea = location == home || location.startsWith('$home/');
  return inOwnArea ? null : home;
}
