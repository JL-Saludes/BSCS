abstract final class Routes {
  static const splash = '/splash';
  static const login = '/login';
  static const accountIssue = '/account-issue';
  static const admin = '/admin';
  static const departmentHead = '/department-head';
  static const guard = '/guard';
}
