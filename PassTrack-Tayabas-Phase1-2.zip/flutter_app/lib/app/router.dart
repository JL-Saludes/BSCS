import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../features/admin/presentation/admin_home_page.dart';
import '../features/auth/presentation/account_issue_page.dart';
import '../features/auth/presentation/login_page.dart';
import '../features/auth/presentation/splash_page.dart';
import '../features/department_head/presentation/department_head_home_page.dart';
import '../features/guard/presentation/guard_home_page.dart';
import '../providers/auth_provider.dart';
import 'route_guard.dart';
import 'routes.dart';

final routerProvider = Provider<GoRouter>((ref) {
  // Bumped whenever auth or profile changes so GoRouter re-runs `redirect`.
  final refresh = ValueNotifier<int>(0);
  ref.listen(authStateProvider, (prev, next) => refresh.value++);
  ref.listen(userProfileProvider, (prev, next) => refresh.value++);

  final router = GoRouter(
    initialLocation: Routes.splash,
    refreshListenable: refresh,
    redirect: (context, state) => resolveRedirect(
      auth: ref.read(authStateProvider),
      profile: ref.read(userProfileProvider),
      location: state.matchedLocation,
    ),
    routes: [
      GoRoute(path: Routes.splash, builder: (c, s) => const SplashPage()),
      GoRoute(path: Routes.login, builder: (c, s) => const LoginPage()),
      GoRoute(
        path: Routes.accountIssue,
        builder: (c, s) => const AccountIssuePage(),
      ),
      GoRoute(path: Routes.admin, builder: (c, s) => const AdminHomePage()),
      GoRoute(
        path: Routes.departmentHead,
        builder: (c, s) => const DepartmentHeadHomePage(),
      ),
      GoRoute(path: Routes.guard, builder: (c, s) => const GuardHomePage()),
    ],
    errorBuilder: (context, state) =>
        const Scaffold(body: Center(child: Text('Page not found.'))),
  );

  ref.onDispose(() {
    router.dispose();
    refresh.dispose();
  });
  return router;
});
