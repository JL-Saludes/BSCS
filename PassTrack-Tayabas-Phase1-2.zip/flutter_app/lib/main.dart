import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app/app.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (!DefaultFirebaseOptions.isConfigured) {
    runApp(const _StartupError(missingConfiguration: true));
    return;
  }
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (_) {
    runApp(const _StartupError(missingConfiguration: false));
    return;
  }
  runApp(const ProviderScope(child: App()));
}

class _StartupError extends StatelessWidget {
  const _StartupError({required this.missingConfiguration});

  final bool missingConfiguration;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PassTrack Tayabas',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF0B3D91),
        useMaterial3: true,
      ),
      home: Scaffold(
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const CircleAvatar(
                      radius: 38,
                      child: Icon(Icons.badge_outlined, size: 38),
                    ),
                    const SizedBox(height: 24),
                    Text(
                      'PassTrack Tayabas',
                      style: Theme.of(context).textTheme.headlineMedium,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Colegio de la Ciudad de Tayabas',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 32),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            const Icon(Icons.cloud_off_outlined, size: 36),
                            const SizedBox(height: 12),
                            Text(
                              missingConfiguration
                                  ? 'Firebase setup required'
                                  : 'Connection unavailable',
                              style: Theme.of(context).textTheme.titleLarge,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              missingConfiguration
                                  ? 'This project has no Firebase configuration yet. Configure your Firebase project and rebuild to enable sign-in and pass management.'
                                  : 'Could not initialize Firebase. Check your configuration and internet connection.',
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'See SETUP.txt in the project ZIP for configuration steps.',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
