abstract final class AppConstants {
  static const String appName = 'CCT Employee Pass Slip System';
  static const String appShortName = 'CCT Pass Slip';
  static const String schoolName = 'Colegio de la Ciudad de Tayabas';
}

abstract final class FirestoreCollections {
  static const String users = 'users';
  static const String employees = 'employees';
  static const String departments = 'departments';
  static const String passSlips = 'pass_slips';
  static const String notifications = 'notifications';
  static const String auditLogs = 'audit_logs';
  static const String settings = 'settings';
}
