abstract final class AuditActions {
  static const employeeCreated = 'ADMIN_CREATED_EMPLOYEE';
  static const employeeUpdated = 'ADMIN_UPDATED_EMPLOYEE';
  static const employeeDeactivated = 'ADMIN_DEACTIVATED_EMPLOYEE';
  static const employeeReactivated = 'ADMIN_REACTIVATED_EMPLOYEE';
  static const departmentCreated = 'ADMIN_CREATED_DEPARTMENT';
  static const departmentUpdated = 'ADMIN_UPDATED_DEPARTMENT';
  static const departmentDeactivated = 'ADMIN_DEACTIVATED_DEPARTMENT';
  static const departmentReactivated = 'ADMIN_REACTIVATED_DEPARTMENT';
  static const userCreated = 'USER_CREATED';
  static const userUpdated = 'USER_UPDATED';
  static const userDisabled = 'USER_DISABLED';
  static const userEnabled = 'USER_ENABLED';
  static const userPasswordReset = 'USER_PASSWORD_RESET_SENT';
  static const passCreated = 'PASS_CREATED';
  static const passUpdated = 'PASS_UPDATED';
  static const passApproved = 'PASS_APPROVED';
  static const passRejected = 'PASS_REJECTED';
  static const passCancelled = 'PASS_CANCELLED';
  static const guardTimeOut = 'GUARD_TIME_OUT';
  static const guardTimeIn = 'GUARD_TIME_IN';
  static const settingsUpdated = 'SETTINGS_UPDATED';
  static const seedLoaded = 'SEED_DATA_LOADED';
  static const seedRemoved = 'SEED_DATA_REMOVED';
}

abstract final class EntityTypes {
  static const employee = 'employee';
  static const department = 'department';
  static const user = 'user';
  static const passSlip = 'pass_slip';
  static const settings = 'settings';
}
