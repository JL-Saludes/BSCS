import 'package:firebase_auth/firebase_auth.dart';

import 'app_exception.dart';

String authErrorMessage(String code) {
  switch (code) {
    case 'invalid-credential':
    case 'wrong-password':
    case 'user-not-found':
      return 'Incorrect email or password.';
    case 'invalid-email':
      return 'Please enter a valid email address.';
    case 'user-disabled':
      return 'This account has been disabled. Contact the administrator.';
    case 'too-many-requests':
      return 'Too many attempts. Please wait a few minutes and try again.';
    case 'network-request-failed':
      return 'No internet connection. Please check your network.';
    default:
      return 'Unable to sign in right now. Please try again.';
  }
}

/// Converts any error into a message that is safe to show to users.
/// Raw Firebase/internal details are never exposed.
String friendlyError(Object error) {
  if (error is AppException) return error.message;
  if (error is FirebaseAuthException) return authErrorMessage(error.code);
  if (error is FirebaseException) {
    switch (error.code) {
      case 'permission-denied':
        return 'You do not have permission to perform this action.';
      case 'unavailable':
        return 'The service is unavailable. Check your internet connection.';
      case 'not-found':
        return 'The requested record could not be found.';
      case 'unauthenticated':
        return 'Your session has expired. Please sign in again.';
      default:
        return 'Something went wrong. Please try again.';
    }
  }
  return 'Something went wrong. Please try again.';
}
