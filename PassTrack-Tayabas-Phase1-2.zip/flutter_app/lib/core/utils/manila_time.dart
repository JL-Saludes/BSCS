import 'package:intl/intl.dart';

/// All school time rules use Philippine Standard Time (UTC+8, no DST),
/// independent of the device time zone.
abstract final class ManilaTime {
  static const Duration offset = Duration(hours: 8);

  /// Shifts an instant so its UTC fields show Manila wall-clock time.
  static DateTime wall(DateTime instant) => instant.toUtc().add(offset);

  /// The instant for a Manila wall-clock date/time.
  static DateTime instant(int y, int m, int d, [int h = 0, int min = 0]) =>
      DateTime.utc(y, m, d, h, min).subtract(offset);

  /// Instant of Manila midnight for the day containing [i].
  static DateTime dayStart(DateTime i) {
    final w = wall(i);
    return instant(w.year, w.month, w.day);
  }

  static bool sameDay(DateTime a, DateTime b) =>
      dayStart(a).isAtSameMomentAs(dayStart(b));

  static int minuteOfDay(DateTime i) {
    final w = wall(i);
    return w.hour * 60 + w.minute;
  }

  static String formatTime(DateTime? i) =>
      i == null ? '—' : DateFormat('h:mm a').format(wall(i));
  static String formatDate(DateTime? i) =>
      i == null ? '—' : DateFormat('MMM d, y').format(wall(i));
  static String formatDateTime(DateTime? i) =>
      i == null ? '—' : DateFormat('MMM d, y h:mm a').format(wall(i));

  static String formatDuration(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    if (h == 0) return '$m min';
    return '$h hr $m min';
  }
}
