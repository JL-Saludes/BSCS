import '../utils/manila_time.dart';

/// Configurable working hours (stored in Firestore `settings/working_hours`).
/// Minutes are counted from midnight, Manila time. Both ends are inclusive,
/// so 5:00 PM (1020) is allowed and 5:01 PM is not.
class WorkingHours {
  const WorkingHours({
    this.startMinute = 480,
    this.endMinute = 1020,
    this.approachingMinutes = 15,
  });

  static const WorkingHours standard = WorkingHours();

  final int startMinute;
  final int endMinute;

  /// Client-side only: how early the "approaching return" (orange) state starts.
  final int approachingMinutes;

  factory WorkingHours.fromMap(Map<String, dynamic> d) => WorkingHours(
    startMinute: (d['startMinute'] as num?)?.toInt() ?? 480,
    endMinute: (d['endMinute'] as num?)?.toInt() ?? 1020,
    approachingMinutes: (d['approachingMinutes'] as num?)?.toInt() ?? 15,
  );

  Map<String, dynamic> toMap() => {
    'startMinute': startMinute,
    'endMinute': endMinute,
    'approachingMinutes': approachingMinutes,
  };

  bool contains(DateTime instant) {
    final m = ManilaTime.minuteOfDay(instant);
    return m >= startMinute && m <= endMinute;
  }

  String get label => '${_fmt(startMinute)} – ${_fmt(endMinute)}';

  static String _fmt(int minute) {
    final h24 = minute ~/ 60;
    final m = minute % 60;
    final h12 = h24 % 12 == 0 ? 12 : h24 % 12;
    final suffix = h24 >= 12 ? 'PM' : 'AM';
    return '$h12:${m.toString().padLeft(2, '0')} $suffix';
  }
}
