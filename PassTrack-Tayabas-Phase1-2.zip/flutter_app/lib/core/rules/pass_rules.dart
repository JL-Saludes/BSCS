import '../../models/enums.dart';
import '../../models/pass_slip.dart';
import '../config/working_hours.dart';
import '../utils/manila_time.dart';

enum PassTiming { notOut, normal, approaching, overdue }

abstract final class PassRules {
  /// Allowed status transitions (mirrors firestore.rules).
  static const Map<PassStatus, Set<PassStatus>> transitions = {
    PassStatus.pending: {
      PassStatus.approved,
      PassStatus.rejected,
      PassStatus.cancelled,
    },
    PassStatus.approved: {PassStatus.out, PassStatus.cancelled},
    PassStatus.out: {PassStatus.completed},
    PassStatus.rejected: {},
    PassStatus.completed: {},
    PassStatus.cancelled: {},
  };

  static bool canTransition(PassStatus from, PassStatus to) =>
      transitions[from]?.contains(to) ?? false;

  /// Returns an error message, or null when the request is valid.
  static String? validateRequest({
    required DateTime date,
    required DateTime requestedTimeOut,
    required DateTime expectedReturn,
    required DateTime now,
  }) {
    if (ManilaTime.dayStart(date).isBefore(ManilaTime.dayStart(now))) {
      return 'The pass date cannot be in the past.';
    }
    if (!ManilaTime.sameDay(date, requestedTimeOut)) {
      return 'The time out must be on the pass date.';
    }
    if (!ManilaTime.sameDay(date, expectedReturn)) {
      return 'The expected return must be on the same day as the pass.';
    }
    if (!expectedReturn.isAfter(requestedTimeOut)) {
      return 'Expected return must be later than the requested time out.';
    }
    return null;
  }

  static String? timeOutBlocker(PassSlip p, DateTime now, WorkingHours hours) {
    if (p.status == PassStatus.cancelled) {
      return 'This pass slip has been cancelled.';
    }
    if (p.status == PassStatus.out || p.actualTimeOut != null) {
      return 'Time Out has already been recorded for this pass slip.';
    }
    if (p.status != PassStatus.approved) {
      return 'Only approved pass slips can be timed out.';
    }
    if (!ManilaTime.dayStart(now).isAtSameMomentAs(p.date)) {
      return 'This pass slip is not valid today.';
    }
    if (!hours.contains(now)) {
      return 'Time Out can only be recorded during working hours (${hours.label}).';
    }
    return null;
  }

  static String? timeInBlocker(PassSlip p, DateTime now, WorkingHours hours) {
    if (p.status == PassStatus.completed || p.actualTimeIn != null) {
      return 'Time In has already been recorded for this pass slip.';
    }
    if (p.status != PassStatus.out || p.actualTimeOut == null) {
      return 'This employee has not been timed out.';
    }
    if (!hours.contains(now)) {
      return 'Time In can only be recorded during working hours (${hours.label}).';
    }
    return null;
  }

  /// OVERDUE is derived, never stored: Out, not returned, past expected return.
  static PassTiming timing(PassSlip p, DateTime now, WorkingHours hours) {
    if (p.status != PassStatus.out || p.actualTimeIn != null) {
      return PassTiming.notOut;
    }
    if (now.isAfter(p.expectedReturnTime)) return PassTiming.overdue;
    final warnFrom = p.expectedReturnTime.subtract(
      Duration(minutes: hours.approachingMinutes),
    );
    if (now.isAfter(warnFrom)) return PassTiming.approaching;
    return PassTiming.normal;
  }
}
