import '../../models/employee.dart';
import '../../models/enums.dart';
import '../../models/pass_slip.dart';
import '../../models/user_profile.dart';
import '../../models/user_role.dart';
import '../errors/app_exception.dart';

/// Client-side mirror of the Firestore rules, used for UI gating and friendly
/// errors. The rules in firestore.rules are the real enforcement.
abstract final class Permissions {
  static bool _is(UserProfile u, UserRole r) => u.active && u.role == r;

  static bool canManageEmployees(UserProfile u) => _is(u, UserRole.admin);
  static bool canManageUsers(UserProfile u) => _is(u, UserRole.admin);
  static bool canManageDepartments(UserProfile u) => _is(u, UserRole.admin);
  static bool canManageSettings(UserProfile u) => _is(u, UserRole.admin);
  static bool canViewAudit(UserProfile u) => _is(u, UserRole.admin);
  static bool canRecordGuardActions(UserProfile u) => _is(u, UserRole.guard);

  static bool canCreatePassFor(UserProfile u, Employee e) {
    if (!e.isActive) return false;
    if (_is(u, UserRole.admin)) return true;
    return _is(u, UserRole.departmentHead) &&
        u.departmentId != null &&
        u.departmentId == e.departmentId;
  }

  /// Teaching → Department Head. Non-Teaching → Admin.
  static UserRole approverRoleFor(EmployeeType type) => switch (type) {
    EmployeeType.teaching => UserRole.departmentHead,
    EmployeeType.nonTeaching => UserRole.admin,
  };

  static bool canDecide(UserProfile u, PassSlip p) {
    if (p.status != PassStatus.pending) return false;
    return switch (p.employeeType) {
      EmployeeType.teaching =>
        _is(u, UserRole.departmentHead) &&
            u.departmentId != null &&
            u.departmentId == p.departmentId,
      EmployeeType.nonTeaching => _is(u, UserRole.admin),
    };
  }

  static bool _managesDepartmentOf(UserProfile u, PassSlip p) =>
      _is(u, UserRole.admin) ||
      (_is(u, UserRole.departmentHead) &&
          u.departmentId != null &&
          u.departmentId == p.departmentId);

  static bool canCancel(UserProfile u, PassSlip p) =>
      (p.status == PassStatus.pending || p.status == PassStatus.approved) &&
      _managesDepartmentOf(u, p);

  static bool canEditPending(UserProfile u, PassSlip p) =>
      p.status == PassStatus.pending && _managesDepartmentOf(u, p);

  static void require(bool allowed) {
    if (!allowed) {
      throw const AppException(
        'You are not authorized to perform this action.',
        code: 'unauthorized',
      );
    }
  }
}
