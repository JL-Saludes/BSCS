package com.passtracktayabas.passes

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
