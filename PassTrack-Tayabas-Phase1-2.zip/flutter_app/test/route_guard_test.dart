import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:passslip/app/route_guard.dart';
import 'package:passslip/app/routes.dart';
import 'package:passslip/models/user_profile.dart';

void main() {
  const noProfile = AsyncData<UserProfile?>(null);

  test('shows splash while auth state is loading', () {
    final result = resolveRedirect(
      auth: const AsyncLoading<User?>(),
      profile: noProfile,
      location: Routes.login,
    );
    expect(result, Routes.splash);
  });

  test('signed-out user is sent to login from a protected route', () {
    final result = resolveRedirect(
      auth: const AsyncData<User?>(null),
      profile: noProfile,
      location: Routes.admin,
    );
    expect(result, Routes.login);
  });

  test('signed-out user may stay on login', () {
    final result = resolveRedirect(
      auth: const AsyncData<User?>(null),
      profile: noProfile,
      location: Routes.login,
    );
    expect(result, isNull);
  });
}
