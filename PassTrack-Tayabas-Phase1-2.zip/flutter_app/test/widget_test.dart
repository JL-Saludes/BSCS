import 'package:flutter_test/flutter_test.dart';
import 'package:passslip/firebase_options.dart';

void main() {
  test('Firebase setup does not silently use placeholder credentials', () {
    if (!DefaultFirebaseOptions.isConfigured) {
      expect(DefaultFirebaseOptions.isConfigured, isFalse);
    } else {
      expect(DefaultFirebaseOptions.currentPlatform.projectId, isNotEmpty);
    }
  });
}
