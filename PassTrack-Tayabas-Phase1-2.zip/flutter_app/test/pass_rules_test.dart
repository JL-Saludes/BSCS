import 'package:flutter_test/flutter_test.dart';
import 'package:passslip/core/config/working_hours.dart';
import 'package:passslip/core/rules/pass_rules.dart';
import 'package:passslip/core/rules/permissions.dart';
import 'package:passslip/core/utils/manila_time.dart';
import 'package:passslip/models/enums.dart';
import 'package:passslip/models/pass_slip.dart';
import 'package:passslip/models/user_profile.dart';
import 'package:passslip/models/user_role.dart';

DateTime at(int h, int m, [int day = 10]) =>
    ManilaTime.instant(2026, 10, day, h, m);

PassSlip pass({
  PassStatus status = PassStatus.approved,
  EmployeeType type = EmployeeType.teaching,
  String dept = 'bscs',
  DateTime? actualTimeOut,
  DateTime? actualTimeIn,
}) => PassSlip(
  passSlipId: 'p1',
  employeeId: 'e1',
  employeeNumber: 'T-1',
  employeeName: 'Test Employee',
  departmentId: dept,
  departmentName: 'Dept',
  employeeType: type,
  date: ManilaTime.instant(2026, 10, 10),
  requestedTimeOut: at(10, 0),
  expectedReturnTime: at(14, 0),
  reason: 'r',
  destination: 'd',
  requestedBy: 'u1',
  requestedByName: 'U',
  status: status,
  actualTimeOut: actualTimeOut,
  actualTimeIn: actualTimeIn,
);

UserProfile user(UserRole role, {String? dept, bool active = true}) =>
    UserProfile(
      uid: 'u-${role.value}',
      email: 'x@x.com',
      fullName: 'User',
      role: role,
      active: active,
      departmentId: dept,
    );

void main() {
  const hours = WorkingHours.standard;

  group('working hours', () {
    test('boundaries', () {
      expect(hours.contains(at(8, 0)), isTrue);
      expect(hours.contains(at(10, 30)), isTrue);
      expect(hours.contains(at(16, 59)), isTrue);
      expect(hours.contains(at(17, 0)), isTrue);
      expect(hours.contains(at(17, 1)), isFalse);
      expect(hours.contains(at(7, 59)), isFalse);
    });

    test('is configurable', () {
      const custom = WorkingHours(startMinute: 540, endMinute: 1080);
      expect(custom.contains(at(8, 30)), isFalse);
      expect(custom.contains(at(18, 0)), isTrue);
    });
  });

  group('approval routing and authorization', () {
    test('routing by employee type', () {
      expect(
        Permissions.approverRoleFor(EmployeeType.teaching),
        UserRole.departmentHead,
      );
      expect(
        Permissions.approverRoleFor(EmployeeType.nonTeaching),
        UserRole.admin,
      );
    });

    test('teaching pass: only the department head of that department', () {
      final p = pass(status: PassStatus.pending);
      expect(
        Permissions.canDecide(user(UserRole.departmentHead, dept: 'bscs'), p),
        isTrue,
      );
      expect(
        Permissions.canDecide(
          user(UserRole.departmentHead, dept: 'tourism'),
          p,
        ),
        isFalse,
      );
      expect(Permissions.canDecide(user(UserRole.admin), p), isFalse);
      expect(Permissions.canDecide(user(UserRole.guard), p), isFalse);
    });

    test('non-teaching pass: only admin', () {
      final p = pass(
        status: PassStatus.pending,
        type: EmployeeType.nonTeaching,
        dept: 'admin',
      );
      expect(Permissions.canDecide(user(UserRole.admin), p), isTrue);
      expect(
        Permissions.canDecide(user(UserRole.departmentHead, dept: 'admin'), p),
        isFalse,
      );
    });

    test('disabled users have no permissions', () {
      final p = pass(status: PassStatus.pending);
      expect(
        Permissions.canDecide(
          user(UserRole.departmentHead, dept: 'bscs', active: false),
          p,
        ),
        isFalse,
      );
    });

    test('guard cannot manage anything', () {
      final g = user(UserRole.guard);
      expect(Permissions.canManageEmployees(g), isFalse);
      expect(Permissions.canManageUsers(g), isFalse);
      expect(Permissions.canRecordGuardActions(g), isTrue);
    });
  });

  group('status transitions', () {
    test('valid path', () {
      expect(
        PassRules.canTransition(PassStatus.pending, PassStatus.approved),
        isTrue,
      );
      expect(
        PassRules.canTransition(PassStatus.approved, PassStatus.out),
        isTrue,
      );
      expect(
        PassRules.canTransition(PassStatus.out, PassStatus.completed),
        isTrue,
      );
    });

    test('invalid transitions', () {
      expect(
        PassRules.canTransition(PassStatus.pending, PassStatus.out),
        isFalse,
      );
      expect(
        PassRules.canTransition(PassStatus.out, PassStatus.cancelled),
        isFalse,
      );
      expect(
        PassRules.canTransition(PassStatus.completed, PassStatus.pending),
        isFalse,
      );
      expect(
        PassRules.canTransition(PassStatus.rejected, PassStatus.approved),
        isFalse,
      );
    });
  });

  group('time out', () {
    test('allowed: approved, today, working hours', () {
      expect(PassRules.timeOutBlocker(pass(), at(10, 30), hours), isNull);
    });
    test('blocked outside working hours', () {
      expect(
        PassRules.timeOutBlocker(pass(), at(17, 1), hours),
        contains('working hours'),
      );
    });
    test('blocked on a different date', () {
      expect(
        PassRules.timeOutBlocker(pass(), at(10, 0, 11), hours),
        contains('not valid today'),
      );
    });
    test('blocked when pending, cancelled or duplicate', () {
      expect(
        PassRules.timeOutBlocker(
          pass(status: PassStatus.pending),
          at(10, 0),
          hours,
        ),
        isNotNull,
      );
      expect(
        PassRules.timeOutBlocker(
          pass(status: PassStatus.cancelled),
          at(10, 0),
          hours,
        ),
        contains('cancelled'),
      );
      expect(
        PassRules.timeOutBlocker(
          pass(status: PassStatus.out, actualTimeOut: at(10, 0)),
          at(10, 5),
          hours,
        ),
        contains('already'),
      );
    });
  });

  group('time in', () {
    final out = pass(status: PassStatus.out, actualTimeOut: at(10, 0));
    test('allowed when out and in working hours', () {
      expect(PassRules.timeInBlocker(out, at(13, 0), hours), isNull);
    });
    test('blocked outside working hours', () {
      expect(PassRules.timeInBlocker(out, at(17, 30), hours), isNotNull);
    });
    test('blocked when not timed out or already in', () {
      expect(
        PassRules.timeInBlocker(pass(), at(13, 0), hours),
        contains('not been timed out'),
      );
      expect(
        PassRules.timeInBlocker(
          pass(
            status: PassStatus.completed,
            actualTimeOut: at(10, 0),
            actualTimeIn: at(12, 0),
          ),
          at(13, 0),
          hours,
        ),
        contains('already'),
      );
    });
  });

  group('overdue and duration', () {
    final out = pass(
      status: PassStatus.out,
      actualTimeOut: at(10, 0),
    ); // expected 14:00
    test('normal / approaching / overdue', () {
      expect(PassRules.timing(out, at(12, 0), hours), PassTiming.normal);
      expect(PassRules.timing(out, at(13, 50), hours), PassTiming.approaching);
      expect(PassRules.timing(out, at(14, 1), hours), PassTiming.overdue);
    });
    test('not overdue unless currently out', () {
      expect(PassRules.timing(pass(), at(15, 0), hours), PassTiming.notOut);
      final done = pass(
        status: PassStatus.completed,
        actualTimeOut: at(10, 0),
        actualTimeIn: at(15, 0),
      );
      expect(PassRules.timing(done, at(16, 0), hours), PassTiming.notOut);
    });
    test('duration and late return', () {
      final done = pass(
        status: PassStatus.completed,
        actualTimeOut: at(10, 0),
        actualTimeIn: at(14, 30),
      );
      expect(done.actualDuration, const Duration(hours: 4, minutes: 30));
      expect(done.returnedLate, isTrue);
    });
  });

  group('request validation', () {
    final now = at(9, 0);
    test('expected return must be after time out', () {
      expect(
        PassRules.validateRequest(
          date: at(0, 0),
          requestedTimeOut: at(10, 0),
          expectedReturn: at(9, 0),
          now: now,
        ),
        isNotNull,
      );
    });
    test('valid request', () {
      expect(
        PassRules.validateRequest(
          date: at(0, 0),
          requestedTimeOut: at(10, 0),
          expectedReturn: at(12, 0),
          now: now,
        ),
        isNull,
      );
    });
    test('past date rejected', () {
      expect(
        PassRules.validateRequest(
          date: at(0, 0, 9),
          requestedTimeOut: at(10, 0, 9),
          expectedReturn: at(12, 0, 9),
          now: now,
        ),
        isNotNull,
      );
    });
  });
}
